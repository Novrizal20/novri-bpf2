import axios from 'axios'

const API_URL = "https://dnuunszymmgxhztriihi.supabase.co/rest/v1/notes"
const API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRudXVuc3p5bW1neGh6dHJpaWhpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE2MzYwOTksImV4cCI6MjA5NzIxMjA5OX0.-hyl50iwq5WNGDQ_RpXyRWlo6yY1lqaOituRym_Aa5M"

const headers = {
    apikey: API_KEY,
    Authorization: `Bearer ${API_KEY}`,
    "Content-Type": "application/json",
}

export const notesAPI = {
    async fetchNotes() {
        const response = await axios.get(API_URL, { headers })
        return response.data
    },

    async createNote(data) {
        const response = await axios.post(API_URL, data, { headers })
        return response.data
    }
}