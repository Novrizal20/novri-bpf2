import { useNavigate } from "react-router-dom";
import { useState } from "react";
import axios from "axios";

import { BsFillExclamationDiamondFill } from "react-icons/bs";
import { ImSpinner2 } from "react-icons/im";

export default function Login() {
    const navigate = useNavigate();

    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    const [dataForm, setDataForm] = useState({
        email: "",
        password: "",
    });

    const handleSubmit = async (e) => {
        e.preventDefault();

        setLoading(true);
        setError("");

        axios
            .post("https://dummyjson.com/auth/login", {
                username: dataForm.email,
                password: dataForm.password,
            })
            .then((response) => {
                console.log(response.data);

                navigate("/");
            })
            .catch((err) => {
                if (err.response) {
                    setError(err.response.data.message);
                } else {
                    setError("Login gagal");
                }
            })
            .finally(() => {
                setLoading(false);
            });
    };

    const handleChange = (evt) => {
        const { name, value } = evt.target;

        setDataForm({
            ...dataForm,
            [name]: value,
        });
    };

    const errorInfo = error ? (
        <div className="bg-red-200 mb-5 p-3 text-sm text-red-700 rounded flex items-center">
            <BsFillExclamationDiamondFill className="text-red-600 me-2" />
            {error}
        </div>
    ) : null;

    const loadingInfo = loading ? (
        <div className="bg-gray-200 mb-5 p-3 text-sm rounded flex items-center">
            <ImSpinner2 className="me-2 animate-spin" />
            Mohon Tunggu...
        </div>
    ) : null;

    return (
        <div>
            <h2 className="text-2xl font-semibold text-gray-700 mb-6 text-center">
                Welcome Back 👋
            </h2>

            {errorInfo}
            {loadingInfo}

            <form onSubmit={handleSubmit}>
                <div className="mb-5">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                        Email Address
                    </label>

                    <input
                        type="text"
                        className="w-full px-4 py-2 bg-gray-50 border border-gray-300 rounded-lg shadow-sm"
                        placeholder="Enter username"
                        name="email"
                        value={dataForm.email}
                        onChange={handleChange}
                    />
                </div>

                <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                        Password
                    </label>

                    <input
                        type="password"
                        className="w-full px-4 py-2 bg-gray-50 border border-gray-300 rounded-lg shadow-sm"
                        placeholder="********"
                        name="password"
                        value={dataForm.password}
                        onChange={handleChange}
                    />
                </div>

                <button
                    type="submit"
                    className="w-full bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-4 rounded-lg"
                >
                    Login
                </button>
            </form>
        </div>
    );
}