import { createRoot } from "react-dom/client";
import "./assets/tailwind.css"
import Sidebar from "./layout/Sidebar";
import Header from "./layout/Header";
import Dashboard from "./pages/Dashboard";
createRoot(document.getElementById("root")).render(
    <div id="app-container" className="bg-gray-100 min-h-screen flex">
        <Sidebar/>
		<div id="main-content" className="flex-1 p-4">
		      <Header />
		      <Dashboard />
	  </div>
    </div>
);